<?php require("../styles/header.php"); ?>

<h4>PHP and MySQL - Student Database</h4>
<?php
#Creating mysqli connection
$conn = new mysqli("localhost", "root", "", "students") or die("Connection failed: " . $conn->connect_error);

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $rollno = $_POST['rollno'];
    $marks = $_POST['marks'];
    $age = $_POST['age'];
    $class = $_POST['name'];

    $sql = "INSERT INTO `users`(`id`, `name`, `rollno`, `marks`, `age`, `class`) VALUES ('','$name','$rollno','$marks','$age','$class')";

    if ($conn->query($sql)) {
    echo "<script>alert('Data inserted in the student database');</script>";
    } else {
    echo "<script>alert('Failed to insert in the student database');</script>". $conn->error;
    }
}
?>
  <button type="button" class="mt-5 mb-5 btn btn-primary" data-toggle="modal" data-target="#Insert">Insert Student</button>
  <button type="button" class="mt-5 mb-5 btn btn-primary" data-toggle="modal" data-target="#DisplayAll">Display All Students</button>
  <button type="button" class="mt-5 mb-5 btn btn-success" data-toggle="modal" data-target="#Display40">Display Students with more than 40 marks</button>

  <!-- The Modal -->
  <div class="modal fade" id="Insert">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Insert Student</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <form action="" method="post">
                  <input type="text" class="form-control mt-3" id="name" placeholder="Enter Name" name="name">
                  <input type="number" class="form-control mt-3" id="rollno" placeholder="Enter Rollno" name="rollno">
                  <input type="number" class="form-control mt-3" id="marks" placeholder="Enter Marks" name="marks">
                  <input type="number" class="form-control mt-3" id="age" placeholder="Enter Age" name="age">
                  <input type="text" class="form-control mt-3" id="class" placeholder="Enter Class" name="class">
                  <input type="submit" class="btn btn-success mt-3 btn-block" name="submit" value="Insert">
            </form>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  <!-- The Modal -->
  <div class="modal fade" id="DisplayAll">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Display All Students</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Rollno</th>
                    <th>Marks</th>
                    <th>Age</th>
                    <th>Class</th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                    $resultUsers = $conn->query("SELECT * FROM users");
                    if ($resultUsers->num_rows > 0) {
                    while($row = $resultUsers->fetch_assoc()) { ?>
                  <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['rollno']?></td>
                    <td><?php echo $row['marks']?></td>
                    <td><?php echo $row['age']?></td>
                    <td><?php echo $row['class']?></td>
                  </tr>
                <?php }  } ?>
                </tbody>
            </table>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

    <div class="modal fade" id="Display40">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Display Students with more than 40 marks</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Rollno</th>
                    <th>Marks</th>
                    <th>Age</th>
                    <th>Class</th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                    $resultUsers = $conn->query("SELECT * FROM users where marks > 40");
                    if ($resultUsers->num_rows > 0) {
                    while($row = $resultUsers->fetch_assoc()) { ?>
                  <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['rollno']?></td>
                    <td><?php echo $row['marks']?></td>
                    <td><?php echo $row['age']?></td>
                    <td><?php echo $row['class']?></td>
                  </tr>
                <?php } $conn->close(); } ?>
                </tbody>
            </table>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

<br>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-7\b.php">Back to Assignemnt-7</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
</div>