<?php require("../styles/header.php"); ?>

<h3>String Management</h3>
<?php echo "Number of words in the \"Hello world!\" string is ".count(explode(" ", "Hello world!")); ?>

<br>
<a class="mt-2 text-white btn btn-info" href="a.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="c.php">Next</a>
</div>