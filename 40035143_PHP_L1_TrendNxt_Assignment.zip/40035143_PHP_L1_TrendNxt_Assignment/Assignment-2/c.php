<?php require("../styles/header.php"); ?>

<h3>String Management</h3>
<?php echo "Reverse the string \"Hello world!\" is \"".strrev("Hello world!")."\""; ?>

<br>
<a class="mt-2 text-white btn btn-info" href="b.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="d.php">Next</a>
</div>
