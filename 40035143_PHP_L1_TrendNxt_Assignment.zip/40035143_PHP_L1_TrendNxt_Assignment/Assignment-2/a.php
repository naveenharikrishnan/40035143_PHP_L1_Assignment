<?php require("../styles/header.php"); ?>

<h3>String Management</h3>
<?php echo "The length of \"Hello world!\" is ".strlen("Hello world!"); ?>

<br>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-1\c.php">Back to Assignemnt-1</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="b.php">Next</a>
</div>