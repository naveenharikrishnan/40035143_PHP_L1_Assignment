<?php require("../styles/header.php"); ?>

<h3>String Management</h3>
<h4>Occurrence of a word "php"</h4>
<?php echo "\"I love php, I love php too!\" - <b>".substr_count('I love php, I love php too!', 'php'); ?>

<br>
<a class="mt-2 text-white btn btn-info" href="c.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-3\a.php">Assignment-3</a>
</div>