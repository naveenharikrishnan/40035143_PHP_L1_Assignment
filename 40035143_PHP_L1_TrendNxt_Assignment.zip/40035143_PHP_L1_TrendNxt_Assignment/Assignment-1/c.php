<?php require("../styles/header.php"); ?>

<h2>Swaping two variables</h2>
    <?php 
        $v1 = 123;
        $v2 = 598;
        echo '<b>Before Process </b><br> variable 1: '.$v1.'<br> variable 2: '.$v2.' <br>';
        
        #Swaping without temp variable
        $v2 = $v1+$v2;
        $v1 = $v2-$v1;
        $v2 = $v2-$v1;
        
        echo '<br><b>After Process</b><br>';
        echo 'variable 1: '.$v1.' <br>';
        echo 'variable 2: '.$v2.' <br>';
?>
<br>
<a class="mt-2 text-white btn btn-info" href="b.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-2\a.php">Assignment-2</a>
</div>