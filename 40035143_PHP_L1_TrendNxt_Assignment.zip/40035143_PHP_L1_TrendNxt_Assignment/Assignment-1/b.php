
<?php require("../styles/header.php"); ?>

<h3>Client IP address for local host is <?php echo $_SERVER['REMOTE_ADDR']; ?></h3>

<br>
<a class="mt-2 text-white btn btn-info" href="a.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="c.php">Next</a>
</div>