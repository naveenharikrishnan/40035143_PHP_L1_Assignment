<?php require("../styles/header.php"); ?>

<h3 class="mb-3">Accept user name and print using echo</h3>

<?php
    if(isset($_POST['submit'])){
?>

<h3>Welcome to Mysite</h3>
<br>
<h3>Hi</h3>
<?php echo $_POST['uname'];?>
<?php 
    } else {
?>
<form class="form-inline" style="padding-left: 420px;" action="" method="post">
    <input type="text" placeholder="Enter Username" class="form-control" name="uname">
  <button type="submit" name="submit" class="ml-2 btn btn-success">Submit</button>
</form>
<?php } ?>

<br>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="b.php">Next</a>
</div>