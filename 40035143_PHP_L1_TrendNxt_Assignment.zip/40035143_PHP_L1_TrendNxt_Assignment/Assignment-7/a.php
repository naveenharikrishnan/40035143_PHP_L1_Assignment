<?php require("../styles/header.php"); ?>

<h4>PHP program to get the size of a file</h4>
<?php
echo "File size of a.php is ".filesize('a.php')." bytes<br>";
echo "File size of b.php is ".filesize('b.php')." bytes";	
?>

<br>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-5\a.php">Back to Assignemnt-5</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="b.php">Next</a>
</div>