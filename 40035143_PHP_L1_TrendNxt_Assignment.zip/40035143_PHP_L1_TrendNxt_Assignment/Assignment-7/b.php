<?php require("../styles/header.php"); ?>

<h4>PHP script to count number of lines in a file</h4>
<?php
$fileData = file_get_contents('a.php');
echo "Number of lines in a a.php is ".count(explode("\n", file_get_contents('a.php')))."<br>";
echo "Number of lines in a b.php is ".count(explode("\n", file_get_contents('b.php')))."";	
?>

<br>
<a class="mt-2 text-white btn btn-info" href="a.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-8\a.php">Assignment-8</a>
</div>