<?php require("../styles/header.php"); ?>

<h3 class="mb-3">Checking whether a number prime or not</h3>
<?php
if(isset($_POST['submit'])){
	$num=$_POST['num'];
	$prime=true;

	#prime number logic
	for($i=$num-1; $i>=2; $i--){
        if($num%$i==0){
            $prime=false;
        }
    }
    echo $num." is a ".($prime?"prime":"not a prime")." number";
}
?>
<form class="mt-3 form-inline" style="padding-left: 420px;" action="" method="post">
    <input type="number" placeholder="Enter Number" class="form-control" name="num">
  <button type="submit" name="submit" class="ml-2 btn btn-success">Find</button>
</form>

<br>
<a class="mt-2 text-white btn btn-info" href="a.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="c.php">Next</a>
</div>