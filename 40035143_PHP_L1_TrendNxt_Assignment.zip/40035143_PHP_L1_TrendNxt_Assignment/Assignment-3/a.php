<?php require("../styles/header.php"); 

echo "<h3>Do-while loop to find out even number between 1 to 100</h3>";
$a = 1;
do {
    if($a%2 == 0){
    	#$a to print numbers, conditional operator to avoid comma(,) after 100
        echo $a.(($a==100)?"":", ");
    }
    $a++;
} while ($a <= 100);
?>
<br>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-2\d.php">Back to Assignemnt-2</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="b.php">Next</a>
</div>