<?php require("../styles/header.php"); ?>

<h4>Remove duplicates from a sorted list</h4>
<?php
$arr=array(1,1,2,2,3,4,5,5);
echo "Input: ";

#printing input array
echo print_array($arr)." <br>";

#removing duplicated by getting unique values
$arr1=array_unique($arr);
echo "Output: ";

#printing output array
echo print_array($arr1);

function print_array($arr) {
	echo "(";
	$j=0;
	foreach($arr as $i){
		echo $i;
		#avoid printing comma(,) for last element 
		if(++$j != count($arr)) 
			echo ", ";
	}
	echo ")";
}
?>

<br>
<a class="mt-2 text-white btn btn-info" href="f.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-4\a.php">Assignment-4</a>
</div>
