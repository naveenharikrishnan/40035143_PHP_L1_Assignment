<?php require("../styles/header.php"); ?>

<h4>Combining string, ("A","E","I","O","U") by putting the separator '-' between each element</h4>
<br>
<?php
$arr = array("A","E","I","O","U");

#used \" to print double quote in the output
echo "Combined string is \"".join("-", $arr)."\"";
?>

<br>
<a class="mt-2 text-white btn btn-info" href="d.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="f.php">Next</a>
</div>