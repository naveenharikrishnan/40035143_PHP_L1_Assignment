<?php require("../styles/header.php"); ?>

<h3 class="mb-3">Print a number reverse</h3>
<?php
if(isset($_POST['submit'])){
	$num=$_POST['num'];
	#reversing number using strrev()
	echo "Reverse of $num is <b>".strrev($num);
}
?>
<form class="mt-3 form-inline" style="padding-left: 375px;" action="" method="post">
    <input type="number" placeholder="Enter Number" class="form-control" name="num">
  <button type="submit" name="submit" class="ml-2 btn btn-success">Reverse number</button>
</form>

<br>
<a class="mt-2 text-white btn btn-info" href="b.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="d.php">Next</a>
</div>