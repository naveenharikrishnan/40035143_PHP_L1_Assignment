<?php require("../styles/header.php"); ?>

<h3 class="mb-3">Sort an array without using predefine function</h3>

<?php
	$arr=array(5,3,6,2,9,4);
	echo "Before sorting: ";
	echo print_array($arr)." <br>";
	for($j = 0; $j < count($arr); $j ++) {
	    for($i = 0; $i < count($arr)-1; $i ++){
	        if($arr[$i] > $arr[$i+1]) {
	            $temp = $arr[$i+1];
	            $arr[$i+1]=$arr[$i];
	            $arr[$i]=$temp;
	        }       
	    }
	}
	echo "After sorting: ";
	echo print_array($arr);

#manually printing array elements without "print_r()"
function print_array($arr) {
	echo "(";
	for($i=0;$i<count($arr);$i++) {
		echo $arr[$i];
		#avoid printing comma(,) for last element 
		if($i!=count($arr)-1)
			echo ", ";
	}
	echo ")";
}
?>

<br>
<a class="mt-2 text-white btn btn-info" href="c.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="e.php">Next</a>
</div>