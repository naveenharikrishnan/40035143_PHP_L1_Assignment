<?php require("../styles/header.php"); ?>

<h4>Find number of days between two dates in PHP</h4>
<?php
if(isset($_POST['submit'])){
	$fdate = strtotime($_POST['fdate']);
	$ldate = strtotime($_POST['ldate']);
	#converted date to time and finds the difference, used abs() so minus value will not come
	echo "Number of days between ".$_POST['fdate']." and ".$_POST['ldate']." is <b>".abs(round(($ldate-$fdate)/ (60 * 60 * 24)));
}
?>
<form class="mt-3 form-inline" style="padding-left: 290px;" action="" method="post">
    <input type="date" class="form-control" name="fdate">
    <input type="date" class="form-control" name="ldate">
  <button type="submit" name="submit" class="ml-2 btn btn-success">Find Difference</button>
</form>

<br>
<a class="mt-2 text-white btn btn-info" href="e.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="g.php">Next</a>
</div>