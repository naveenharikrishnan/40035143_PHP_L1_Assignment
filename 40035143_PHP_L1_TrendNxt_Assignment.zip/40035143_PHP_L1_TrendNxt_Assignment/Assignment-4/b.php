<?php require("../styles/header.php"); ?>

<h4>HTML Forms</h4>

<?php
$nameError = $emailError = $genderError = $commentsError = $websiteError = "";
$name = $email = $gender = $comments = $website = "";

if (isset($_POST["submit"])) {
  if (empty($_POST["name"])) {
    $nameError = "Name is required";
  }

  if (empty($_POST["email"])) {
    $emailError = "Email is required";
  }

  if (empty($_POST["website"])) {
    $websiteError = "Website is required";
  }

  if (empty($_POST["comments"])) {
    $commentsError = "Comments are required";
  }

  if (empty($_POST["gender"])) {
    $genderError = "Gender is required";
  }
}
?>
<form class="mt-3 text-left" style="width:710px; padding-left: 415px;" action="" method="post">
    <span>Name:</span>
    <input type="text" class="form-control" name="name">
    <?php echo "<span class='text-right text-danger'>$nameError</span><br>";?>
    
    <span>Email:</span>
    <input type="email" class="form-control" name="email">
    <?php echo "<span class='text-danger'>$emailError</span><br>";?>

    <span>Website:</span>
    <input type="text" class="form-control" name="website">
    <?php echo "<span class='text-danger'>$websiteError</span><br>";?>
    
    <span>Comments:</span>
    <textarea class="mb-3 form-control" name="comments" rows="3"></textarea>
    <?php echo "<span class='text-danger'>$commentsError</span><br>";?>
    
    <span>Gender:</span> <br>
		Male: <input type="radio" class="ml-1" value="male" name="gender"> 
		Female: <input type="radio" class="ml-1 mb-3" value="female" name="gender"><br>
    <?php echo "<span class='text-danger'>$genderError</span><br>";?>

  <button type="submit" name="submit" class="mt-2 btn btn-success">Submit</button>
</form>

<br>
<a class="mt-2 text-white btn btn-info" href="a.php">Back</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-5\a.php">Assignment-5</a>
</div>