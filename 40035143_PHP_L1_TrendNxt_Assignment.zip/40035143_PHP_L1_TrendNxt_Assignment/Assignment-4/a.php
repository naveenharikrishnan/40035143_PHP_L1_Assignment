<?php require("../styles/header.php"); ?>

<h4>PHP File Upload and Form Management</h4>
<?php
if(isset($_POST['submit'])){
    move_uploaded_file($_FILES["file"]["tmp_name"], basename($_FILES["file"]["name"]));
    echo "<script>alert('File uploaded to Assignment-4 folder');</script>";
}
?>
<form class="mt-3 form-inline" enctype="multipart/form-data" style="padding-left: 340px;" action="" method="post">
    <input type="file" class="form-control" name="file">
  <button type="submit" name="submit" class="ml-2 btn btn-success">Upload File</button>
</form>

<br>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-3\g.php">Back to Assignemnt-3</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="b.php">Next</a>
</div>