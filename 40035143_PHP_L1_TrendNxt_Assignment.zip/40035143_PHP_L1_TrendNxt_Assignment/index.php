
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style type="text/css">
      td{text-align: left;}
  </style>

<div class="container-fluid">
    <table width="100%" >
        <tr>
            <th colspan="2" style="font-size:30px;"" class="text-right">PHP TrendNxt Assignment - L1</th>
            <td class="text-right font-weight-bold text-info">
            40035143<br>
            Naveen H<br>
            naveen.h60@wipro.com
            </td>
        </tr>   
    </table>
    <table class="table text-center">
        <tr>
            <th width="20%">Name</th>
            <th colspan="2" width="40%">Topic</th>
        </tr>
        <tr>
            <th class="text-left" rowspan="3">1. PHP Basics</th>
            <th class="text-right">a)</th>
            <td><a href="Assignment-1/a.php">Create a simple HTML form and accept the user name and display the name through PHP echo statement</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">b)</th>
            <td>
                <a href="Assignment-1/b.php">Write a PHP script to get the client IP address</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">c)</th>
            <td>
                <a href="Assignment-1/c.php">Write a PHP program to swap two variables</a>
            </td>
        </tr>
        <tr>
            <th class="text-left" rowspan="4">2. String Management</th>
            <th class="text-right">a)</th>
            <td>
                <a href="Assignment-2/a.php">Return the length of the string "Hello world!"</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">b)</th>
            <td>
                <a href="Assignment-2/b.php">Count the number of word in the string "Hello world!"</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">c)</th>
            <td>
                <a href="Assignment-2/c.php">Reverse the string "Hello world!"</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">d)</th>
            <td>
                <a href="Assignment-2/d.php">Write a program in PHP to find the occurrence of a word "php" in a sentence.</a>
            </td>
        </tr>
        <tr>
            <th class="text-left" rowspan="7">3. Date/ Number/ Loop /Array Management</th>
            <th class="text-right">a)</th>
            <td>
                <a href="Assignment-3/a.php">Write a program using do-while loop to find out even number between 1 to 100</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">b)</th>
            <td>
                <a href="Assignment-3/b.php">How to find whether a number prime or not</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">c)</th>
            <td>
                <a href="Assignment-3/c.php">How to print a number reverse</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">d)</th>
            <td>
                <a href="Assignment-3/d.php">Write a program to sort an array without using predefine function. array(5,3,6,2,9,4)</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">e)</th>
            <td>
                <a href="Assignment-3/e.php">Suppose you have an array like this $arr = array ("A","E","I","O","U"); and you wish to combine it into a string, by putting the separator '-' between each element of the array</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">f)</th>
            <td>
                <a href="Assignment-3/f.php">Write a program to find no of days between two dates in Php?</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">g)</th>
            <td>
                <a href="Assignment-3/g.php">Write a PHP program to remove duplicates from a sorted list</a>
            </td>
        </tr>
        <tr>
            <th class="text-left" rowspan="2">4. PHP File Upload and Form Management</th>
            <th class="text-right">a)</th>
            <td>
                <a href="Assignment-4/a.php">Write a Program to upload a file in php</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">b)</th>
            <td>
                <a href="Assignment-4/b.php">Create a simple form with name, Email, Website, Comments and Gender. Validate in PHP</a>
            </td>
        </tr>
        <tr>
            <th class="text-left">5. OOPS IN PHP</th>
            <th class="text-right">a)</th>
            <td>
                <a href="Assignment-5/a.php">Write a simple PHP class which displays the following string. 'MyClass class has initialized!'</a>
            </td>
        </tr>
        <tr>
            <th class="text-left">6. Assignment</th>
            <th colspan="2">Question not available in the PDF</th>
        </tr>
        <tr>
            <th class="text-left" rowspan="2">7. PHP FILE</th>
            <th class="text-right">a)</th>
            <td>
                <a href="Assignment-7/a.php">Write a PHP program to get the size of a file</a>
            </td>
        </tr>
        <tr>
            <th class="text-right">b)</th>
            <td>
                <a href="Assignment-7/b.php">Write a PHP script to count number of lines in a file</a>
            </td>
        </tr>
        <tr>
            <th class="text-left" rowspan="2">8. MySQL</th>
            <th class="text-right">a)</th>
            <td>
                <a href="Assignment-8/a.php">Create a database "students" Create 1 tables "users" with columns ( id, name, rollno, marks, age, class)> Create 1 page to insert the user using HTML form> Create a page to show all the users with marks > 40</a>
            </td>
        </tr>
    </table>
</body>
</html>