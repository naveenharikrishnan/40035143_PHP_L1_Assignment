<?php require("../styles/header.php"); ?>

<h4>Simple PHP class</h4>
<?php
#creating class
class MyClass{
	#constructor
    function __construct(){
        echo 'MyClass class has initialized!';
    }
}
new MyClass();
?>

<br>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-4\b.php">Back to Assignemnt-4</a>
<a class="mt-2 text-white btn btn-info" href="..\index.php">Mainmenu</a>
<a class="mt-2 text-white btn btn-info" href="..\Assignment-7\a.php">Assignment-7</a>
</div>